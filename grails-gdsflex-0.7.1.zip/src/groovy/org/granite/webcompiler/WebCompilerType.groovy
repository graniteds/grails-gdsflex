package org.granite.webcompiler;

public enum WebCompilerType {
	application,
	module,
	library
}
