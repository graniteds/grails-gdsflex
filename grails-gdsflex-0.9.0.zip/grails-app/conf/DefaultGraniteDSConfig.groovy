
graniteConfig {

    gravityEnabled = false
    gravityServletClassName = "org.granite.gravity.tomcat.GravityTomcatServlet"
    
    dataDispatchEnabled = false
    
}

as3Config {
    domainJar = null
    extraClasses = []
	excludeClasses = []
    generateServices = true
    autoCompileFlex = true
}
