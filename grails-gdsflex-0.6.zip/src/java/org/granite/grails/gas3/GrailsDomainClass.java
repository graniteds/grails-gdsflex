package org.granite.grails.gas3;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.granite.generator.as3.As3Type;
import org.granite.generator.as3.reflect.JavaEntityBean;
import org.granite.generator.as3.reflect.JavaTypeFactory;


public class GrailsDomainClass extends JavaEntityBean {
	
	private Map<String, As3Type> hasMany = null;
	

    public GrailsDomainClass(JavaTypeFactory provider, Class<?> type, URL url) {
        super(provider, type, url);
        
        try {
        	@SuppressWarnings("unchecked")
        	Map<String, Class<?>> hasMany = (Map<String, Class<?>>)type.getMethod("getHasMany").invoke(null);
        	if (hasMany != null && !hasMany.isEmpty()) {
        		this.hasMany = new HashMap<String, As3Type>();
	        	for (Map.Entry<String, Class<?>> me : hasMany.entrySet()) {
	        		this.hasMany.put(me.getKey(), getProvider().getAs3Type(me.getValue()));
	        	}
        	}
        }
        catch (Exception e) {
        	// No hasMany
        }
    }
    
    public Map<String, As3Type> getHasMany() {
    	return hasMany;
    }

}
