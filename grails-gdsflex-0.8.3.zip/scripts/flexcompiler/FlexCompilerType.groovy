
public enum FlexCompilerType {
	application,
	library
}
