@artifact.package@


class @artifact.name@ implements java.io.Serializable {

    static constraints = {
	}
	
	String uid
}
